# Elegant Bath Instagram research (read-only)

Inspected public profile: https://www.instagram.com/elegantbath_/
Verified attribution on profile: username `@elegantbath_`, display name `ElegantBathInc`; profile links to `elegantbath.ca`. The profile bio describes a premium plumbing-fixtures showroom specializing in custom homes and multi-unit projects. Posts below are published by this profile.

## Useful posts (original URLs and caption excerpts)

1. **May 13, 2026 — completed custom master ensuite**  
   https://www.instagram.com/elegantbath_/p/DYTHq0PGs2h/  
   “Where craftsmanship meets calm. This custom master ensuite features a curated collection of luxury plumbing fixtures with refined finishes, clean lines, and timeless detail throughout. Proud to have supplied the fixtures for this beautiful custom home build.” Carousel; visible frame shows a dark stone vanity/ensuite with warm metallic fixtures.
2. **April 25, 2026 — Riobel / House of Rohl faucet**  
   https://www.instagram.com/elegantbath_/p/DXkBo6IGsBE/  
   “Sleek lines, warm brass tones, and timeless detail. ✨ Riobel faucet by House of Rohl elevating every moment.”
3. **February 12, 2026 — Brizo Black Onyx showroom display (reel)**  
   https://www.instagram.com/elegantbath_/reel/DUr136nmKfK/  
   “Take a look at @brizofaucet Black Onyx finish in Display at our Showroom.”
4. **February 5, 2026 — luxury-home details**  
   https://www.instagram.com/elegantbath_/p/DUZLY3Qkm4T/  
   “Details that speak for themselves 🤍✨ Crafted to stand out, designed to last.” Location displayed: Ocean Park.
5. **January 30, 2026 — custom home/bath inspiration**  
   https://www.instagram.com/elegantbath_/p/DUKX2aMEXmc/  
   “Would you start or end your day here? 🛁✨ Custom details that turn homes into showpieces.” Location displayed: Ocean Park.
6. **January 27, 2026 — Langley custom home**  
   https://www.instagram.com/elegantbath_/p/DUBRB1QlOq1/  
   “-Langley Custom Home 🏡 Timeless style, custom details, and flawless craftsmanship ✨✅” Location displayed: Brookswood, Langley. Carousel.
7. **August 16, 2025 — Rubinet faucet collection/display (reel)**  
   https://www.instagram.com/elegantbath_/reel/DNbt8r7yYpF/  
   “Our Rubinet faucet collection combines luxury, craftsmanship, and performance—perfect for kitchens & baths that make a statement. Come see the display in person and get inspired for your next project.”
8. **May 31, 2025 — Kohler showroom display (carousel)**  
   https://www.instagram.com/elegantbath_/p/DKVL2rVBq6g/  
   “Come explore our full @kohler display, featuring the latest in bathroom and kitchen fixtures. From bold modern designs to timeless classics, Kohler delivers quality, innovation, and that ‘wow’ factor your space deserves.” Invites in-store visits and homeowners, designers, and contractors.

## Branding / visual direction

- Profile avatar is the Elegant BATH wordmark: blue/dark-blue lettering and flowing wave mark on a white circular field. The downloaded profile-avatar file is small and is not a production-ready logo master.
- Observed palette (visual estimate, not sampled hex values): corporate blue/navy and brighter cyan-blue; white; charcoal/graphite in showroom displays. Product imagery repeatedly features chrome/stainless and warm brass/gold. Use blue/white as brand colors; let brass/chrome appear as product accents rather than asserted brand colors.
- Grid/showroom imagery includes dark display walls, illuminated fixture niches, brass and chrome faucets, and Kohler/Rubinet display areas. Project posts support a “custom home / completed ensuite” portfolio section.

## Saved assets and limits

- `/workspace/elegant-bath-research/instagram/instagram-profile-logo.jpg` — profile avatar saved using Chrome’s built-in **Save image as**. Low-resolution avatar; not a high-resolution logo master.
- `/workspace/elegant-bath-research/instagram/profile-grid-screenshot.png` and `profile-grid-browser-ui.webp` — profile/logo/showroom evidence screenshots.
- `/workspace/elegant-bath-research/instagram/custom-ensuite-post-screenshot.png` and `custom-ensuite-post-browser-ui.webp` — post/page screenshot evidence for the May 13, 2026 ensuite carousel. Screenshots are evidence only, not high-resolution source media.
- Instagram’s content-photo context menu did not offer an image-specific save option (it showed a page-level “Save as…”), so no post media was saved. No sign-in or login was attempted; public post/caption content was accessible anonymously, while Instagram displayed signup nudges.
