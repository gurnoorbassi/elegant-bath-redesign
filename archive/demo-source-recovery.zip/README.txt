Public served source recovery, not a repository clone. Original HTML preserved without rewriting. All discovered same-origin links/assets fetched; external CDN/stock/font dependencies only inventoried, not crawled. Branding folder contains previously collected official-business assets and provenance. Instagram project attribution is unverified.
Related repository: https://github.com/gurnoorbassi/elegant-bath-redesign
README ties repo to Elegant Bath business, not explicitly to demo. Main index.html is UPDATED_INDEX placeholder, not served demo HTML.
